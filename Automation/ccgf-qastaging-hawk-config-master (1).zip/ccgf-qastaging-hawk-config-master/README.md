# hawk-values-umbr-qa-staging
Hawk Project's CICD Umbrella helm chart for QA Staging environment

The value files are service specific. The naming convention is
```values-dev-umbrella-<SERVICE-NAME>.yaml```

The deployment umbrella value chart is called values-dev-umbrella.yaml.
